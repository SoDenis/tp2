def imprime_lista_de_faturas(lista_de_faturas):
    """TODO: documentação"""

    # TODO: Implementar esta função
    # ...
    pass