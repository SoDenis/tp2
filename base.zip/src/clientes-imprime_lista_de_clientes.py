def imprime_lista_de_clientes(lista_de_clientes):
    """TODO: documentação"""

    #TODO: Implementar esta função
    # ...
