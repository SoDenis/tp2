from clientes import cria_novo_cliente, imprime_lista_de_clientes
from faturas import cria_nova_fatura, imprime_lista_de_faturas
from io_ficheiros import (carrega_as_listas_dos_ficheiros,
                          guarda_as_listas_em_ficheiros)
from io_terminal import pause
from veiculos import cria_novo_veiculo, imprime_lista_de_veiculos



####################################################################
#
# TODO: Copie para aqui o código de cada uma das funções nos
# ficheiros com o nome main-*.py e faça um commit de cada vez
# Quando este ficheiro estiver completo com todas as suas funções,
# deve ser o unico ficheiro main.py existente, deve apagar
# todos os outros ficheiros main-*.py, e inclusive estes comentários

# ...




####################################################################

if __name__ == "__main__":
    menu()
